# QuickDL — One-Tap Android Video Downloader

**QuickDL** is a standalone, production-structured Android video downloader built with **Kotlin**, **Jetpack Compose**, **Material 3**, and real **yt-dlp + FFmpeg + Aria2c** binaries via [`io.github.junkfood02.youtubedl-android`](https://github.com/yausername/youtubedl-android) ([JitPack/Maven docs](https://jitpack.io/p/yausername/youtubedl-android)) — the same native engine foundation used by [YTDLnis](https://github.com/deniscerri/ytdlnis).

Its core feature is a **native Android Quick Settings Tile** (`QuickDownloadTileService`) paired with an **invisible, zero-animation clipboard handoff Activity** (`ClipboardHandoffActivity`) so you can copy any video link, pull down the notification shade, tap **Quick Download**, and start downloading in the background without ever opening the main app.

## Key Capabilities

- **One-Tap Quick Settings Tile (`QuickDownloadTileService`)**:
  - 4 distinct states: **Idle**, **Downloading** (with live progress subtitle), **Completed** (checkmark, auto-resets to Idle), and **Error**.
  - Android 10–15 compliant clipboard reading via `ClipboardHandoffActivity` (`Theme.QuickDL.TransparentHandoff`, `taskAffinity=""`, `excludeFromRecents="true"`, `noHistory="true"`, zero transition animation).
  - Main UI (`MainActivity`) is never launched during the Quick Settings workflow.
- **Real `yt-dlp` + `FFmpeg` + `Aria2c` Engine (`YtDlpEngine`)**:
  - Default mode downloads the **highest available original quality** (`bestvideo*+bestaudio/best`, including 4K/8K, HLS, and DASH).
  - Merges separate audio/video streams with FFmpeg without re-encoding whenever possible.
  - Supports resumable downloads (`--continue`), configurable retries, concurrent fragments, optional `aria2c`, and in-app `yt-dlp` binary updates.
- **Foreground Service & Recovery (`DownloadForegroundService` + `DownloadRecoveryWorker`)**:
  - Android 14+ compliant `dataSync` Foreground Service with `START_STICKY` + Room persistence + WorkManager online recovery.
- **Rich Notifications (`DownloadNotificationManager`)**:
  - Video thumbnail prefetch, 400ms throttled smooth progress bar, speed, downloaded/total size, ETA, **Cancel** action, **Open** & **Share** actions on completion, and **Retry** action on failure.
- **Modern Scoped Storage (`StorageManager`)**:
  - Stages downloads in app-private storage for FFmpeg merging, then atomically publishes to `Movies/Downloader/` via `MediaStore` (`IS_PENDING = 1 -> 0`) on Android 10+ (or user-selected SAF folder) so videos immediately appear in the device Gallery.
- **Material 3 Jetpack Compose UI**:
  - Home screen (URL input, Paste, Download, Active & Recent downloads), History screen, Settings screen, Dynamic Colors, Dark/Light/System themes, and `ACTION_SEND` Share Sheet support.


## Build from a phone (no computer)

Use the included GitHub Actions workflow at `.github/workflows/android-build.yml`. Follow [`BUILD_FROM_PHONE.md`](BUILD_FROM_PHONE.md) to upload the project from your phone and build downloadable Debug APK artifacts in GitHub's cloud.

## Build Instructions

### Prerequisites
- **Android Studio** Ladybug (2024.2) or newer
- **JDK 17**
- **Android SDK 35** (minSdk 26 / Android 8.0+)
- Internet connection for initial Gradle sync (`mavenCentral()`, `google()`, `jitpack.io`)

### Build Debug & Release APKs

1. Unzip `QuickDL-Android-Project.zip` and open the `QuickDL/` folder in Android Studio.
2. Let Gradle sync download dependencies (including `io.github.junkfood02.youtubedl-android:library:0.18.1`, `:ffmpeg:0.18.1`, and `:aria2c:0.18.1`).
3. Build from Android Studio or terminal:

```bash
# Generate Debug APKs (per-ABI + universal)
./gradlew assembleDebug

# Run JVM unit tests
./gradlew testDebugUnitTest

# Generate Release APKs (configure signingConfigs in app/build.gradle.kts first)
./gradlew assembleRelease
```

> **Note on Gradle Wrapper JAR**: Because this archive was generated offline without network access, `gradle-wrapper.jar` is not bundled. Opening the project in Android Studio automatically provisions the Gradle wrapper, or run `gradle wrapper --gradle-version 8.11.1` once locally.

## Setting Up the Quick Settings Tile on Your Device

1. Install and launch **QuickDL** once to grant the Android 13+ **Notifications** permission (`POST_NOTIFICATIONS`).
2. Pull down the Android notification shade twice and tap the **Edit (pencil)** icon.
3. Drag the **Quick Download** tile into your active Quick Settings panel.
4. Copy any supported video URL from Chrome, YouTube, X, Instagram, TikTok, etc., pull down the shade, and tap **Quick Download**.

## What Remains Untested (Requires Local Machine & Device)

Because this project was authored in an offline environment without an Android SDK, Gradle Maven cache, or connected Android device, the following items have **not** been executed yet and must be verified locally:

1. **Gradle compilation & dependency resolution** (`./gradlew assembleDebug` / `assembleRelease` with `youtubedl-android:0.18.1`).
2. **Real-device Quick Settings Tile tests (Android 13/14/15)**:
   - Copying a YouTube URL and tapping the tile to confirm zero visible UI, zero Recents entry, and immediate background download start.
   - Verifying tile state transitions (Idle -> Downloading -> Completed checkmark -> Idle, and Error).
   - Verifying empty clipboard, unsupported URL, duplicate active URL, and multiple newline-separated URLs.
3. **Real media extraction & FFmpeg stream merging**:
   - Highest available quality selection (including 4K DASH/HLS streams) and FFmpeg audio+video muxing without re-encoding.
   - Verifying published files appear immediately in `Movies/Downloader/` and the device Gallery.
4. **Resilience & OS restrictions**:
   - Network disconnect/reconnect retry and `DownloadRecoveryWorker` recovery.
   - Process termination survival with `DownloadForegroundService` (`dataSync`) on Android 14+.
   - Multiple simultaneous downloads and notification grouping/throttling.

## License & Attribution

- Engine powered by [`yausername/youtubedl-android`](https://github.com/yausername/youtubedl-android) (maintained by `junkfood02`).
- Architecture inspired by and designed for clean compatibility with [`deniscerri/ytdlnis`](https://github.com/deniscerri/ytdlnis) (GPLv3). Per YTDLnis licensing terms, this standalone project uses the independent name **QuickDL** (`com.quickdl.app`).
