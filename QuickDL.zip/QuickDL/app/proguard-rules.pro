# Keep youtubedl-android & Jackson/Gson reflection models used by VideoInfo
-keep class com.yausername.** { *; }
-dontwarn com.yausername.**

# Keep Room entities & DAOs
-keep class com.quickdl.app.data.db.** { *; }
