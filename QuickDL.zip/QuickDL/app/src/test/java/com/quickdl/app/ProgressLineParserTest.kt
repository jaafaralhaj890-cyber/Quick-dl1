package com.quickdl.app

import com.quickdl.app.core.engine.ProgressLineParser
import com.quickdl.app.core.model.DownloadProgress
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProgressLineParserTest {

    @Test
    fun parsesDownloadLineWithSizeSpeedAndEta() {
        val line = "[download]  42.5% of ~100.00MiB at  5.00MiB/s ETA 00:12"
        val parsed = ProgressLineParser.parse(
            callbackPercent = 42.5f,
            callbackEtaSeconds = 12L,
            line = line,
            previous = DownloadProgress()
        )
        assertEquals(42.5f, parsed.percent, 0.01f)
        assertEquals(12L, parsed.etaSeconds)
        assertEquals(104_857_600L, parsed.totalBytes)
        assertEquals(5_242_880L, parsed.speedBytesPerSec)
        assertTrue(parsed.downloadedBytes > 44_000_000L)
    }

    @Test
    fun detectsFfmpegMergerPhase() {
        val line = "[Merger] Merging formats into \"/storage/emulated/0/Movies/Downloader/video.mp4\""
        val parsed = ProgressLineParser.parse(
            callbackPercent = 100f,
            callbackEtaSeconds = 0L,
            line = line,
            previous = DownloadProgress(percent = 98f)
        )
        assertEquals(99f, parsed.percent, 0.01f)
        assertTrue(parsed.phaseLabel.contains("Merging"))
    }
}
