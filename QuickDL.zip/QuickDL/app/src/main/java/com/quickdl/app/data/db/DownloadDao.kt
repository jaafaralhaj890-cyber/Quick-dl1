package com.quickdl.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY createdAtMillis DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE status IN ('QUEUED', 'EXTRACTING', 'DOWNLOADING', 'MERGING', 'PAUSED') ORDER BY createdAtMillis ASC")
    fun observeActive(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE status IN ('COMPLETED', 'FAILED', 'CANCELLED') ORDER BY createdAtMillis DESC")
    fun observeHistory(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status IN ('QUEUED', 'EXTRACTING', 'DOWNLOADING', 'MERGING')")
    suspend fun getPendingOrRunning(): List<DownloadEntity>

    @Query("SELECT COUNT(*) FROM downloads WHERE normalizedUrl = :normalizedUrl AND status IN ('QUEUED', 'EXTRACTING', 'DOWNLOADING', 'MERGING')")
    suspend fun countActiveByNormalizedUrl(normalizedUrl: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DownloadEntity)

    @Update
    suspend fun update(entity: DownloadEntity)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM downloads WHERE status IN ('COMPLETED', 'FAILED', 'CANCELLED')")
    suspend fun clearHistory()
}
