package com.quickdl.app.core.model

sealed class TileState {
    data object Idle : TileState()
    data class Downloading(
        val activeCount: Int,
        val aggregatePercent: Int
    ) : TileState()
    data class Completed(val title: String) : TileState()
    data class Error(val message: String) : TileState()
}
