package com.quickdl.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.quickdl.app.ui.MainViewModel
import com.quickdl.app.ui.screens.HistoryScreen
import com.quickdl.app.ui.screens.HomeScreen
import com.quickdl.app.ui.screens.SettingsScreen

private enum class Destination(val route: String, val label: String) {
    HOME("home", "Home"),
    HISTORY("history", "History"),
    SETTINGS("settings", "Settings")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickDlAppRoot(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: Destination.HOME.route

    val urlInput by viewModel.urlInput.collectAsStateWithLifecycle()
    val activeDownloads by viewModel.activeDownloads.collectAsStateWithLifecycle()
    val historyDownloads by viewModel.historyDownloads.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val isUpdatingYtDlp by viewModel.isUpdatingYtDlp.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.snackbarEvents.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(title = { Text("QuickDL") })
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar {
                Destination.entries.forEach { dest ->
                    val icon = when (dest) {
                        Destination.HOME -> Icons.Rounded.Home
                        Destination.HISTORY -> Icons.Rounded.History
                        Destination.SETTINGS -> Icons.Rounded.Settings
                    }
                    NavigationBarItem(
                        selected = currentRoute == dest.route,
                        onClick = {
                            if (currentRoute != dest.route) {
                                navController.navigate(dest.route) {
                                    popUpTo(Destination.HOME.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = { Icon(icon, contentDescription = dest.label) },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Destination.HOME.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Destination.HOME.route) {
                HomeScreen(
                    urlInput = urlInput,
                    activeDownloads = activeDownloads,
                    recentDownloads = historyDownloads,
                    onUrlChange = viewModel::onUrlInputChange,
                    onPasteClick = viewModel::pasteFromClipboard,
                    onDownloadClick = viewModel::submitInputUrls,
                    onPause = viewModel::pauseDownload,
                    onResume = viewModel::resumeDownload,
                    onCancel = viewModel::cancelDownload,
                    onRetry = viewModel::retryDownload,
                    onDelete = viewModel::deleteHistoryItem
                )
            }
            composable(Destination.HISTORY.route) {
                HistoryScreen(
                    history = historyDownloads,
                    onRetry = viewModel::retryDownload,
                    onDelete = viewModel::deleteHistoryItem,
                    onClearAll = viewModel::clearHistory
                )
            }
            composable(Destination.SETTINGS.route) {
                SettingsScreen(
                    settings = settings,
                    isUpdatingYtDlp = isUpdatingYtDlp,
                    onUpdateSettings = viewModel::updateSettings,
                    onUpdateYtDlpClick = viewModel::updateYtDlpBinary
                )
            }
        }
    }
}
