package com.quickdl.app.tile

import android.content.ComponentName
import android.content.Context
import android.service.quicksettings.TileService
import com.quickdl.app.core.model.TileState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Coordinates Quick Settings tile state transitions across the Foreground Service and TileService.
 * Uses native TileService.requestListeningState() so the tile refreshes cleanly even if the
 * main app UI has never been opened.
 */
object TileStateBus {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow<TileState>(TileState.Idle)
    val state: StateFlow<TileState> = _state.asStateFlow()

    private var resetJob: Job? = null

    fun setDownloading(context: Context, activeCount: Int, aggregatePercent: Int) {
        resetJob?.cancel()
        _state.value = TileState.Downloading(activeCount, aggregatePercent.coerceIn(0, 100))
        requestTileRefresh(context)
    }

    fun setCompleted(context: Context, title: String) {
        resetJob?.cancel()
        _state.value = TileState.Completed(title)
        requestTileRefresh(context)
        resetJob = scope.launch {
            delay(2_800L)
            if (_state.value is TileState.Completed) {
                _state.value = TileState.Idle
                requestTileRefresh(context)
            }
        }
    }

    fun setError(context: Context, message: String) {
        resetJob?.cancel()
        _state.value = TileState.Error(message)
        requestTileRefresh(context)
        resetJob = scope.launch {
            delay(3_500L)
            if (_state.value is TileState.Error) {
                _state.value = TileState.Idle
                requestTileRefresh(context)
            }
        }
    }

    fun setIdle(context: Context) {
        resetJob?.cancel()
        _state.value = TileState.Idle
        requestTileRefresh(context)
    }

    private fun requestTileRefresh(context: Context) {
        runCatching {
            TileService.requestListeningState(
                context.applicationContext,
                ComponentName(context.applicationContext, QuickDownloadTileService::class.java)
            )
        }
    }
}
