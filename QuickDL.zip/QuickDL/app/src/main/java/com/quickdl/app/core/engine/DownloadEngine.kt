package com.quickdl.app.core.engine

import com.quickdl.app.core.model.AppSettings
import com.quickdl.app.core.model.DownloadProgress
import java.io.File

data class ExtractedMetadata(
    val title: String,
    val uploader: String?,
    val thumbnailUrl: String?,
    val durationSeconds: Long?,
    val resolution: String?,
    val ext: String?
)

data class EngineDownloadResult(
    val stagedFile: File,
    val title: String,
    val extension: String,
    val resolution: String?
)

/**
 * Clean abstraction over the underlying extraction/download engine.
 * Implemented by [YtDlpEngine] using junkfood02/youtubedl-android and designed so
 * YTDLnis command templates, cookies, or PO-token providers can be plugged in later.
 */
interface DownloadEngine {
    suspend fun fetchMetadata(url: String): Result<ExtractedMetadata>

    suspend fun download(
        processId: String,
        url: String,
        stagingDir: File,
        settings: AppSettings,
        onProgress: (DownloadProgress) -> Unit
    ): Result<EngineDownloadResult>

    fun cancel(processId: String): Boolean
}
