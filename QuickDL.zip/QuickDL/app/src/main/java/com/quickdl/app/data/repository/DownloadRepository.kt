package com.quickdl.app.data.repository

import com.quickdl.app.core.model.DownloadItem
import com.quickdl.app.data.db.DownloadDao
import com.quickdl.app.data.db.DownloadEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class DownloadRepository(private val dao: DownloadDao) {

    fun observeAll(): Flow<List<DownloadItem>> =
        dao.observeAll().map { list -> list.map { it.toModel() } }

    fun observeActive(): Flow<List<DownloadItem>> =
        dao.observeActive().map { list -> list.map { it.toModel() } }

    fun observeHistory(): Flow<List<DownloadItem>> =
        dao.observeHistory().map { list -> list.map { it.toModel() } }

    suspend fun getById(id: String): DownloadItem? = dao.getById(id)?.toModel()

    suspend fun getPendingOrRunning(): List<DownloadItem> =
        dao.getPendingOrRunning().map { it.toModel() }

    suspend fun isNormalizedUrlActive(normalizedUrl: String): Boolean =
        dao.countActiveByNormalizedUrl(normalizedUrl) > 0

    suspend fun upsert(item: DownloadItem, normalizedUrl: String) {
        dao.upsert(DownloadEntity.fromModel(item, normalizedUrl))
    }

    suspend fun deleteById(id: String) = dao.deleteById(id)

    suspend fun clearHistory() = dao.clearHistory()
}
