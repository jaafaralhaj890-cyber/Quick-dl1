package com.quickdl.app.core.queue

import android.content.Context
import android.util.Log
import com.quickdl.app.core.clipboard.SmartClipboardHandler
import com.quickdl.app.core.engine.DownloadEngine
import com.quickdl.app.core.model.DownloadItem
import com.quickdl.app.core.model.DownloadStatus
import com.quickdl.app.core.notification.DownloadNotificationManager
import com.quickdl.app.core.settings.SettingsRepository
import com.quickdl.app.core.storage.StorageManager
import com.quickdl.app.data.repository.DownloadRepository
import com.quickdl.app.service.DownloadRecoveryWorker
import com.quickdl.app.tile.TileStateBus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Coordinates concurrent downloads, duplicate prevention, exponential retry backoff,
 * persistent Room state updates, notification rendering, and Quick Settings tile state.
 */
class DownloadQueueManager(
    private val context: Context,
    private val engine: DownloadEngine,
    private val repository: DownloadRepository,
    private val storageManager: StorageManager,
    private val notificationManager: DownloadNotificationManager,
    private val settingsRepository: SettingsRepository,
    private val clipboardHandler: SmartClipboardHandler
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val activeNormalizedUrls = ConcurrentHashMap<String, String>()
    private val progressSnapshot = ConcurrentHashMap<String, Float>()

    @Volatile
    private var concurrencySemaphore = Semaphore(2)

    @Volatile
    private var configuredConcurrency = 2

    var onActiveCountChanged: ((activeCount: Int, aggregatePercent: Int) -> Unit)? = null

    fun isUrlActive(normalizedUrl: String): Boolean {
        return activeNormalizedUrls.containsKey(normalizedUrl)
    }

    fun activeCount(): Int = activeJobs.size

    fun enqueue(url: String, existingId: String? = null) {
        val normalized = clipboardHandler.normalizeUrl(url)
        if (existingId == null && activeNormalizedUrls.containsKey(normalized)) {
            return
        }

        val id = existingId ?: UUID.randomUUID().toString()
        activeNormalizedUrls[normalized] = id
        progressSnapshot[id] = 0f

        val job = scope.launch {
            val settings = settingsRepository.getCurrentSettings()
            if (settings.maxConcurrentDownloads != configuredConcurrency) {
                configuredConcurrency = settings.maxConcurrentDownloads
                concurrencySemaphore = Semaphore(configuredConcurrency)
            }

            var item = repository.getById(id)?.copy(
                status = DownloadStatus.QUEUED,
                errorMessage = null,
                progressPercent = 0f
            ) ?: DownloadItem(
                id = id,
                url = url,
                status = DownloadStatus.QUEUED
            )

            repository.upsert(item, normalized)
            if (settings.showNotifications) {
                notificationManager.showProgress(item, "Queued…", force = true)
            }
            notifyAggregateState()

            try {
                concurrencySemaphore.withPermit {
                    // Step 1: Extract real video metadata (title, thumbnail, resolution)
                    item = item.copy(status = DownloadStatus.EXTRACTING)
                    repository.upsert(item, normalized)
                    if (settings.showNotifications) {
                        notificationManager.showProgress(item, "Fetching video info…", force = true)
                    }

                    engine.fetchMetadata(url).onSuccess { meta ->
                        item = item.copy(
                            title = meta.title,
                            uploader = meta.uploader,
                            thumbnailUrl = meta.thumbnailUrl,
                            durationSeconds = meta.durationSeconds,
                            resolution = meta.resolution,
                            formatExtension = meta.ext
                        )
                        repository.upsert(item, normalized)
                        notificationManager.prefetchThumbnail(id, meta.thumbnailUrl)
                    }

                    // Step 2: Execute yt-dlp + FFmpeg download with recoverable retry backoff
                    val stagingDir = storageManager.createStagingDir(id)
                    var attempt = 0
                    var downloadResult = engine.download(id, url, stagingDir, settings) { progress ->
                        val nextStatus = if (progress.phaseLabel.contains("Merging", ignoreCase = true)) {
                            DownloadStatus.MERGING
                        } else {
                            DownloadStatus.DOWNLOADING
                        }
                        item = item.copy(
                            status = nextStatus,
                            progressPercent = progress.percent,
                            downloadedBytes = progress.downloadedBytes,
                            totalBytes = progress.totalBytes,
                            speedBytesPerSec = progress.speedBytesPerSec,
                            etaSeconds = progress.etaSeconds
                        )
                        progressSnapshot[id] = progress.percent
                        if (settings.showNotifications) {
                            notificationManager.showProgress(item, progress.phaseLabel)
                        }
                        notifyAggregateState()
                    }

                    while (downloadResult.isFailure && attempt < settings.maxRetryCount && isRecoverableError(downloadResult.exceptionOrNull())) {
                        attempt++
                        item = item.copy(retryCount = attempt, status = DownloadStatus.DOWNLOADING)
                        repository.upsert(item, normalized)
                        if (settings.showNotifications) {
                            notificationManager.showProgress(
                                item,
                                "Reconnecting (retry $attempt/${settings.maxRetryCount})…",
                                force = true
                            )
                        }
                        delay(2_000L * attempt)
                        downloadResult = engine.download(id, url, stagingDir, settings) { progress ->
                            item = item.copy(
                                status = DownloadStatus.DOWNLOADING,
                                progressPercent = progress.percent,
                                downloadedBytes = progress.downloadedBytes,
                                totalBytes = progress.totalBytes,
                                speedBytesPerSec = progress.speedBytesPerSec,
                                etaSeconds = progress.etaSeconds
                            )
                            progressSnapshot[id] = progress.percent
                            if (settings.showNotifications) {
                                notificationManager.showProgress(item, progress.phaseLabel)
                            }
                            notifyAggregateState()
                        }
                    }

                    val engineOutput = downloadResult.getOrThrow()

                    // Step 3: Publish merged file atomically into Movies/Downloader/ (or custom SAF folder)
                    val published = storageManager.publishFile(
                        stagedFile = engineOutput.stagedFile,
                        desiredTitle = item.title.takeIf { it != "Fetching video info…" } ?: engineOutput.title,
                        extension = engineOutput.extension,
                        isAudioOnly = settings.audioOnly,
                        customTreeUri = settings.customTreeUri
                    ).getOrThrow()

                    storageManager.cleanupStagingDir(id)

                    item = item.copy(
                        status = DownloadStatus.COMPLETED,
                        progressPercent = 100f,
                        outputUri = published.uri.toString(),
                        outputDisplayPath = published.displayPath,
                        fileSizeBytes = published.fileSizeBytes,
                        formatExtension = engineOutput.extension,
                        completedAtMillis = System.currentTimeMillis(),
                        errorMessage = null
                    )
                    repository.upsert(item, normalized)

                    if (settings.showNotifications) {
                        notificationManager.showCompleted(item)
                    }
                    if (activeJobs.size <= 1) {
                        TileStateBus.setCompleted(context, item.title)
                    }
                }
            } catch (_: CancellationException) {
                engine.cancel(id)
                val current = repository.getById(id)
                val finalStatus = if (current?.status == DownloadStatus.PAUSED) {
                    DownloadStatus.PAUSED
                } else {
                    storageManager.cleanupStagingDir(id)
                    DownloadStatus.CANCELLED
                }
                repository.upsert(item.copy(status = finalStatus), normalized)
                notificationManager.cancelNotification(id)
            } catch (t: Throwable) {
                Log.e(TAG, "Download failed for $url", t)
                val friendly = toUserFriendlyError(t)
                item = item.copy(
                    status = DownloadStatus.FAILED,
                    errorMessage = friendly
                )
                repository.upsert(item, normalized)
                if (settings.showNotifications) {
                    notificationManager.showError(item, friendly)
                }
                TileStateBus.setError(context, friendly)

                if (isRecoverableError(t)) {
                    DownloadRecoveryWorker.scheduleWhenOnline(context)
                }
            } finally {
                activeJobs.remove(id)
                activeNormalizedUrls.remove(normalized)
                progressSnapshot.remove(id)
                notifyAggregateState()
            }
        }

        activeJobs[id] = job
        notifyAggregateState()
    }

    fun pause(downloadId: String) {
        scope.launch {
            val item = repository.getById(downloadId) ?: return@launch
            val normalized = clipboardHandler.normalizeUrl(item.url)
            repository.upsert(item.copy(status = DownloadStatus.PAUSED), normalized)
            engine.cancel(downloadId)
            activeJobs[downloadId]?.cancel()
        }
    }

    fun resume(downloadId: String) {
        scope.launch {
            val item = repository.getById(downloadId) ?: return@launch
            enqueue(item.url, existingId = item.id)
        }
    }

    fun cancel(downloadId: String) {
        engine.cancel(downloadId)
        activeJobs[downloadId]?.cancel()
        notificationManager.cancelNotification(downloadId)
    }

    fun retry(downloadId: String) {
        scope.launch {
            val item = repository.getById(downloadId) ?: return@launch
            enqueue(item.url, existingId = item.id)
        }
    }

    private fun notifyAggregateState() {
        val count = activeJobs.size
        val avg = if (count == 0) {
            0
        } else {
            val sum = progressSnapshot.values.sum()
            (sum / count.coerceAtLeast(1)).toInt().coerceIn(0, 100)
        }
        if (count > 0) {
            TileStateBus.setDownloading(context, count, avg)
        }
        onActiveCountChanged?.invoke(count, avg)
    }

    private fun isRecoverableError(t: Throwable?): Boolean {
        if (t == null) return false
        if (t is IOException) return true
        val msg = t.message.orEmpty().lowercase()
        return msg.contains("timed out") ||
            msg.contains("network") ||
            msg.contains("connection reset") ||
            msg.contains("unable to download") ||
            msg.contains("temporary failure")
    }

    private fun toUserFriendlyError(t: Throwable): String {
        val msg = t.message.orEmpty()
        val lower = msg.lowercase()
        return when {
            lower.contains("unsupported url") -> "This link is not supported."
            lower.contains("video unavailable") || lower.contains("private video") -> "Video is unavailable or private."
            lower.contains("no space left") || lower.contains("enospc") -> "Insufficient storage space on device."
            lower.contains("timed out") || lower.contains("unable to resolve host") -> "Network connection lost. Tap Retry when back online."
            lower.contains("http error 403") || lower.contains("expired") -> "Link expired or access denied (HTTP 403)."
            lower.contains("ffmpeg") -> "FFmpeg failed to merge audio and video streams."
            msg.isNotBlank() -> msg.lineSequence().first().take(160)
            else -> "Unexpected download error."
        }
    }

    companion object {
        private const val TAG = "DownloadQueueManager"
    }
}
