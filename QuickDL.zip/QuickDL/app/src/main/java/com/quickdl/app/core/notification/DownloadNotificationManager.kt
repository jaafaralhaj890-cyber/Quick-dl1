package com.quickdl.app.core.notification

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.quickdl.app.R
import com.quickdl.app.core.model.DownloadItem
import com.quickdl.app.core.model.DownloadStatus
import com.quickdl.app.service.DownloadActionReceiver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Manages modern Android notifications for QuickDL:
 * - Ongoing foreground summary notification (Android 14+ compliant)
 * - Per-download progress notifications with video thumbnail, percentage, speed, size, ETA, and Cancel action
 * - Throttled updates (~400ms per download) to keep progress animations silky smooth without flickering
 * - Rich Completed notifications with thumbnail, final file size, Open action, and Share action
 * - Clear Error notifications with one-tap Retry action
 * - Never opens MainActivity automatically
 */
class DownloadNotificationManager(private val context: Context) {

    private val notificationManager = NotificationManagerCompat.from(context)
    private val lastNotifyTimeMs = ConcurrentHashMap<String, Long>()
    private val thumbnailCache = ConcurrentHashMap<String, Bitmap>()

    fun ensureChannels() {
        val sysManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val activeChannel = NotificationChannel(
            CHANNEL_DOWNLOADS,
            context.getString(R.string.channel_downloads_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = context.getString(R.string.channel_downloads_desc)
            setShowBadge(false)
        }

        val completedChannel = NotificationChannel(
            CHANNEL_COMPLETED,
            context.getString(R.string.channel_completed_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.channel_completed_desc)
        }

        val alertsChannel = NotificationChannel(
            CHANNEL_ALERTS,
            context.getString(R.string.channel_alerts_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.channel_alerts_desc)
        }

        sysManager.createNotificationChannels(listOf(activeChannel, completedChannel, alertsChannel))
    }

    fun buildForegroundSummaryNotification(activeCount: Int, aggregatePercent: Int): Notification {
        val title = if (activeCount <= 1) {
            "Downloading video…"
        } else {
            "Downloading $activeCount videos…"
        }
        val subtitle = if (aggregatePercent > 0) "$aggregatePercent% overall" else "Preparing streams…"

        return NotificationCompat.Builder(context, CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_notif_download)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setGroup(GROUP_DOWNLOADS)
            .setGroupSummary(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    suspend fun prefetchThumbnail(downloadId: String, thumbnailUrl: String?) {
        if (thumbnailUrl.isNullOrBlank() || thumbnailCache.containsKey(downloadId)) return
        withContext(Dispatchers.IO) {
            runCatching {
                val conn = (URL(thumbnailUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5_000
                    readTimeout = 5_000
                    instanceFollowRedirects = true
                }
                conn.inputStream.use { stream ->
                    BitmapFactory.decodeStream(stream)?.let { bmp ->
                        thumbnailCache[downloadId] = bmp
                    }
                }
            }
        }
    }

    fun showProgress(item: DownloadItem, phaseLabel: String, force: Boolean = false) {
        if (!canPostNotifications()) return
        val now = SystemClock.elapsedRealtime()
        val last = lastNotifyTimeMs[item.id] ?: 0L
        if (!force && now - last < PROGRESS_THROTTLE_MS) return
        lastNotifyTimeMs[item.id] = now

        val percentInt = item.progressPercent.toInt().coerceIn(0, 100)
        val indeterminate = item.status == DownloadStatus.QUEUED ||
            item.status == DownloadStatus.EXTRACTING ||
            item.status == DownloadStatus.MERGING ||
            (percentInt == 0 && item.downloadedBytes == 0L)

        val metrics = buildProgressLine(item, phaseLabel)
        val cancelPendingIntent = DownloadActionReceiver.createPendingIntent(
            context = context,
            action = DownloadActionReceiver.ACTION_CANCEL,
            downloadId = item.id,
            requestCode = notificationIdFor(item.id) + 10_000
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_notif_download)
            .setContentTitle(item.title)
            .setContentText(metrics)
            .setSubText(if (!indeterminate) "$percentInt%" else phaseLabel)
            .setProgress(100, percentInt, indeterminate)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setGroup(GROUP_DOWNLOADS)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .addAction(R.drawable.ic_notif_cancel, "Cancel", cancelPendingIntent)

        thumbnailCache[item.id]?.let { builder.setLargeIcon(it) }

        notificationManager.notify(notificationIdFor(item.id), builder.build())
    }

    fun showCompleted(item: DownloadItem) {
        if (!canPostNotifications()) return
        lastNotifyTimeMs.remove(item.id)

        val notifId = notificationIdFor(item.id)
        val fileUri = item.outputUri?.let { Uri.parse(it) }
        val mimeType = if (item.formatExtension in setOf("m4a", "mp3", "opus", "ogg")) "audio/*" else "video/*"

        val openPendingIntent = fileUri?.let { uri ->
            val openIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            PendingIntent.getActivity(
                context,
                notifId + 20_000,
                openIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        val sharePendingIntent = fileUri?.let { uri ->
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "Share video")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            PendingIntent.getActivity(
                context,
                notifId + 30_000,
                chooser,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        val sizeText = formatBytes(item.fileSizeBytes)
        val contentText = buildString {
            append("Saved")
            if (sizeText.isNotEmpty()) append(" · $sizeText")
            item.resolution?.let { append(" · $it") }
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_COMPLETED)
            .setSmallIcon(R.drawable.ic_notif_done)
            .setContentTitle(item.title)
            .setContentText(contentText)
            .setSubText("Download complete")
            .setAutoCancel(true)
            .setOngoing(false)
            .setProgress(0, 0, false)
            .setGroup(GROUP_DOWNLOADS)
            .setCategory(NotificationCompat.CATEGORY_STATUS)

        openPendingIntent?.let {
            builder.setContentIntent(it)
            builder.addAction(R.drawable.ic_notif_open, "Open", it)
        }
        sharePendingIntent?.let {
            builder.addAction(R.drawable.ic_notif_share, "Share", it)
        }
        thumbnailCache.remove(item.id)?.let { bmp ->
            builder.setLargeIcon(bmp)
            builder.setStyle(
                NotificationCompat.BigPictureStyle()
                    .bigPicture(bmp)
                    .bigLargeIcon(null as Bitmap?)
            )
        }

        notificationManager.notify(notifId, builder.build())
    }

    fun showError(item: DownloadItem, reason: String) {
        if (!canPostNotifications()) return
        lastNotifyTimeMs.remove(item.id)
        thumbnailCache.remove(item.id)

        val notifId = notificationIdFor(item.id)
        val retryPendingIntent = DownloadActionReceiver.createPendingIntent(
            context = context,
            action = DownloadActionReceiver.ACTION_RETRY,
            downloadId = item.id,
            requestCode = notifId + 40_000
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_notif_error)
            .setContentTitle("Download failed: ${item.title}")
            .setContentText(reason)
            .setStyle(NotificationCompat.BigTextStyle().bigText(reason))
            .setAutoCancel(true)
            .setOngoing(false)
            .setProgress(0, 0, false)
            .addAction(R.drawable.ic_notif_retry, "Retry", retryPendingIntent)

        notificationManager.notify(notifId, builder.build())
    }

    fun showInfoAlert(title: String, message: String) {
        if (!canPostNotifications()) return
        val builder = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_notif_download)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setTimeoutAfter(5_000L)

        notificationManager.notify(INFO_ALERT_NOTIFICATION_ID, builder.build())
    }

    fun cancelNotification(downloadId: String) {
        lastNotifyTimeMs.remove(downloadId)
        thumbnailCache.remove(downloadId)
        notificationManager.cancel(notificationIdFor(downloadId))
    }

    private fun buildProgressLine(item: DownloadItem, phaseLabel: String): String {
        if (item.status == DownloadStatus.EXTRACTING) return "Fetching best quality streams…"
        if (item.status == DownloadStatus.MERGING) return "Merging video & audio with FFmpeg…"
        if (item.status == DownloadStatus.QUEUED) return "Queued…"

        val parts = mutableListOf<String>()
        if (item.totalBytes > 0) {
            parts.add("${formatBytes(item.downloadedBytes)} / ${formatBytes(item.totalBytes)}")
        } else if (item.downloadedBytes > 0) {
            parts.add(formatBytes(item.downloadedBytes))
        }
        if (item.speedBytesPerSec > 0) {
            parts.add("${formatBytes(item.speedBytesPerSec)}/s")
        }
        if (item.etaSeconds > 0) {
            parts.add("ETA ${formatEta(item.etaSeconds)}")
        }
        return if (parts.isEmpty()) phaseLabel else parts.joinToString(" · ")
    }

    private fun canPostNotifications(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun notificationIdFor(downloadId: String): Int {
        return 2000 + (downloadId.hashCode() and 0x7FFF)
    }

    companion object {
        const val CHANNEL_DOWNLOADS = "quickdl_active_downloads"
        const val CHANNEL_COMPLETED = "quickdl_completed_downloads"
        const val CHANNEL_ALERTS = "quickdl_alerts"
        const val GROUP_DOWNLOADS = "com.quickdl.app.DOWNLOADS_GROUP"
        const val FOREGROUND_SUMMARY_ID = 1001
        private const val INFO_ALERT_NOTIFICATION_ID = 1002
        private const val PROGRESS_THROTTLE_MS = 400L

        fun formatBytes(bytes: Long): String {
            if (bytes <= 0L) return ""
            val units = arrayOf("B", "KB", "MB", "GB")
            var value = bytes.toDouble()
            var unitIdx = 0
            while (value >= 1024.0 && unitIdx < units.lastIndex) {
                value /= 1024.0
                unitIdx++
            }
            return String.format(Locale.US, "%.1f %s", value, units[unitIdx])
        }

        fun formatEta(seconds: Long): String {
            if (seconds < 60) return "${seconds}s"
            val mins = seconds / 60
            val secs = seconds % 60
            return if (mins < 60) "${mins}m ${secs}s" else "${mins / 60}h ${mins % 60}m"
        }
    }
}
