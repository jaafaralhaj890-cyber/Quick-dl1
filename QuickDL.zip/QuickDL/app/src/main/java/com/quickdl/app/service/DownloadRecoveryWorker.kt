package com.quickdl.app.service

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.quickdl.app.QuickDlApplication

/**
 * WorkManager recovery hook that restarts interrupted downloads once network connectivity
 * is restored. Complements [DownloadForegroundService] rather than replacing it.
 */
class DownloadRecoveryWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as QuickDlApplication
        val pending = app.downloadRepository.getPendingOrRunning()
        if (pending.isNotEmpty()) {
            runCatching { DownloadForegroundService.recoverPending(applicationContext) }
        }
        return Result.success()
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "quickdl_network_recovery"

        fun scheduleWhenOnline(context: Context) {
            val request = OneTimeWorkRequestBuilder<DownloadRecoveryWorker>()
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                UNIQUE_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }
    }
}
