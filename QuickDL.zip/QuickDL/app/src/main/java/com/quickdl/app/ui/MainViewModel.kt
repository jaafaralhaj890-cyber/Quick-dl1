package com.quickdl.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.quickdl.app.QuickDlApplication
import com.quickdl.app.core.clipboard.ClipboardParseResult
import com.quickdl.app.core.engine.EngineInitializer
import com.quickdl.app.core.model.AppSettings
import com.quickdl.app.core.model.DownloadItem
import com.quickdl.app.service.DownloadForegroundService
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as QuickDlApplication

    val activeDownloads: StateFlow<List<DownloadItem>> = app.downloadRepository.observeActive()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val historyDownloads: StateFlow<List<DownloadItem>> = app.downloadRepository.observeHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val settings: StateFlow<AppSettings> = app.settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _isUpdatingYtDlp = MutableStateFlow(false)
    val isUpdatingYtDlp: StateFlow<Boolean> = _isUpdatingYtDlp.asStateFlow()

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val snackbarEvents = _snackbarEvents.asSharedFlow()

    fun onUrlInputChange(value: String) {
        _urlInput.value = value
    }

    fun pasteFromClipboard() {
        when (val result = app.clipboardHandler.readAndExtract()) {
            is ClipboardParseResult.ValidUrls -> {
                _urlInput.value = result.urls.joinToString("\n")
            }
            is ClipboardParseResult.Empty -> _snackbarEvents.tryEmit("Clipboard is empty.")
            is ClipboardParseResult.NoValidUrls -> _snackbarEvents.tryEmit("No supported video URL found in clipboard.")
            is ClipboardParseResult.AccessBlocked -> _snackbarEvents.tryEmit("Clipboard access blocked by OS.")
        }
    }

    fun submitInputUrls() {
        val raw = _urlInput.value.trim()
        when (val parsed = app.clipboardHandler.extractUrlsFromText(raw)) {
            is ClipboardParseResult.ValidUrls -> {
                var started = 0
                for (url in parsed.urls) {
                    val normalized = app.clipboardHandler.normalizeUrl(url)
                    if (!app.queueManager.isUrlActive(normalized)) {
                        DownloadForegroundService.enqueueUrl(app, url)
                        started++
                    }
                }
                if (started > 0) {
                    _urlInput.value = ""
                    _snackbarEvents.tryEmit(if (started == 1) "Download started" else "Started $started downloads")
                } else {
                    _snackbarEvents.tryEmit("This video is already downloading.")
                }
            }
            else -> _snackbarEvents.tryEmit("Enter or paste a valid video URL.")
        }
    }

    fun enqueueSharedText(sharedText: String) {
        when (val parsed = app.clipboardHandler.extractUrlsFromText(sharedText)) {
            is ClipboardParseResult.ValidUrls -> {
                parsed.urls.forEach { DownloadForegroundService.enqueueUrl(app, it) }
                _snackbarEvents.tryEmit("Queued ${parsed.urls.size} shared link(s)")
            }
            else -> _snackbarEvents.tryEmit("Shared text did not contain a supported URL.")
        }
    }

    fun pauseDownload(id: String) = DownloadForegroundService.sendCommand(
        app, DownloadForegroundService.ACTION_PAUSE, id
    )

    fun resumeDownload(id: String) = DownloadForegroundService.sendCommand(
        app, DownloadForegroundService.ACTION_RESUME, id
    )

    fun cancelDownload(id: String) = DownloadForegroundService.sendCommand(
        app, DownloadForegroundService.ACTION_CANCEL, id
    )

    fun retryDownload(id: String) = DownloadForegroundService.sendCommand(
        app, DownloadForegroundService.ACTION_RETRY, id
    )

    fun deleteHistoryItem(id: String) {
        viewModelScope.launch { app.downloadRepository.deleteById(id) }
    }

    fun clearHistory() {
        viewModelScope.launch { app.downloadRepository.clearHistory() }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { app.settingsRepository.update(transform) }
    }

    fun updateYtDlpBinary() {
        if (_isUpdatingYtDlp.value) return
        viewModelScope.launch {
            _isUpdatingYtDlp.value = true
            EngineInitializer.updateYtDlp(app)
                .onSuccess { status ->
                    _snackbarEvents.tryEmit("yt-dlp update status: ${status?.name ?: "UP_TO_DATE"}")
                }
                .onFailure { err ->
                    _snackbarEvents.tryEmit("yt-dlp update failed: ${err.message ?: "unknown error"}")
                }
            _isUpdatingYtDlp.value = false
        }
    }
}
