package com.quickdl.app.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.quickdl.app.core.model.AppSettings
import com.quickdl.app.core.model.PreferredFormat
import com.quickdl.app.core.model.ThemeMode
import com.quickdl.app.core.model.VideoQualityPreset
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    isUpdatingYtDlp: Boolean,
    onUpdateSettings: ((AppSettings) -> AppSettings) -> Unit,
    onUpdateYtDlpClick: () -> Unit
) {
    val context = LocalContext.current
    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            onUpdateSettings { it.copy(customTreeUri = uri.toString()) }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SettingsCard("Quick Settings Tile") {
                ToggleRow(
                    title = "Enable one-tap tile downloads",
                    subtitle = "Read clipboard & start background download when tapping the Quick Settings tile",
                    checked = settings.quickTileEnabled,
                    onCheckedChange = { enabled -> onUpdateSettings { it.copy(quickTileEnabled = enabled) } }
                )
            }
        }

        item {
            SettingsCard("Quality & Format") {
                Text("Default video quality", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VideoQualityPreset.entries.forEach { preset ->
                        FilterChip(
                            selected = settings.qualityPreset == preset,
                            onClick = { onUpdateSettings { it.copy(qualityPreset = preset) } },
                            label = { Text(preset.label) }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Container format", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PreferredFormat.entries.forEach { fmt ->
                        FilterChip(
                            selected = settings.preferredFormat == fmt,
                            onClick = { onUpdateSettings { it.copy(preferredFormat = fmt) } },
                            label = { Text(fmt.label) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                ToggleRow(
                    title = "Audio-only mode",
                    subtitle = "Extract highest quality M4A audio track instead of video",
                    checked = settings.audioOnly,
                    onCheckedChange = { audio -> onUpdateSettings { it.copy(audioOnly = audio) } }
                )
            }
        }

        item {
            SettingsCard("Storage & Queue") {
                Text(
                    text = if (settings.customTreeUri == null) "Default folder: Movies/Downloader/" else "Custom folder selected",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { folderPicker.launch(null) }) {
                        Text("Choose custom folder")
                    }
                    if (settings.customTreeUri != null) {
                        OutlinedButton(onClick = { onUpdateSettings { it.copy(customTreeUri = null) } }) {
                            Text("Reset default")
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Max concurrent downloads: ${settings.maxConcurrentDownloads}")
                Slider(
                    value = settings.maxConcurrentDownloads.toFloat(),
                    onValueChange = { v -> onUpdateSettings { it.copy(maxConcurrentDownloads = v.roundToInt()) } },
                    valueRange = 1f..5f,
                    steps = 3
                )
                Text("Automatic retries on network error: ${settings.maxRetryCount}")
                Slider(
                    value = settings.maxRetryCount.toFloat(),
                    onValueChange = { v -> onUpdateSettings { it.copy(maxRetryCount = v.roundToInt()) } },
                    valueRange = 0f..6f,
                    steps = 5
                )
                ToggleRow(
                    title = "Use Aria2c multi-connection downloader",
                    subtitle = "Accelerate direct downloads with parallel HTTP segments when supported",
                    checked = settings.useAria2c,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(useAria2c = v) } }
                )
                ToggleRow(
                    title = "Sanitize filenames automatically",
                    subtitle = "Strip unsafe filesystem characters and keep filenames concise",
                    checked = settings.autoCleanFilename,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(autoCleanFilename = v) } }
                )
            }
        }

        item {
            SettingsCard("Appearance & Notifications") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { onUpdateSettings { it.copy(themeMode = mode) } },
                            label = { Text(mode.label) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                ToggleRow(
                    title = "Material You dynamic colors",
                    subtitle = "Match wallpaper palette on Android 12+",
                    checked = settings.dynamicColors,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(dynamicColors = v) } }
                )
                ToggleRow(
                    title = "Download notifications",
                    subtitle = "Show live progress, completion, and retry notifications",
                    checked = settings.showNotifications,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(showNotifications = v) } }
                )
            }
        }

        item {
            SettingsCard("Download Engine (yt-dlp + FFmpeg)") {
                Button(
                    onClick = onUpdateYtDlpClick,
                    enabled = !isUpdatingYtDlp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (isUpdatingYtDlp) "Updating yt-dlp…" else "Update yt-dlp binary")
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
