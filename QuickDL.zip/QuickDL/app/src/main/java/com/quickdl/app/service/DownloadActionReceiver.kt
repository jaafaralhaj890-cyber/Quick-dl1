package com.quickdl.app.service

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Handles notification action taps (Cancel, Retry, Pause, Resume) without opening MainActivity.
 */
class DownloadActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val downloadId = intent.getStringExtra(DownloadForegroundService.EXTRA_DOWNLOAD_ID) ?: return
        when (intent.action) {
            ACTION_CANCEL -> DownloadForegroundService.sendCommand(
                context, DownloadForegroundService.ACTION_CANCEL, downloadId
            )
            ACTION_RETRY -> DownloadForegroundService.sendCommand(
                context, DownloadForegroundService.ACTION_RETRY, downloadId
            )
            ACTION_PAUSE -> DownloadForegroundService.sendCommand(
                context, DownloadForegroundService.ACTION_PAUSE, downloadId
            )
            ACTION_RESUME -> DownloadForegroundService.sendCommand(
                context, DownloadForegroundService.ACTION_RESUME, downloadId
            )
        }
    }

    companion object {
        const val ACTION_CANCEL = "com.quickdl.app.notif.CANCEL"
        const val ACTION_RETRY = "com.quickdl.app.notif.RETRY"
        const val ACTION_PAUSE = "com.quickdl.app.notif.PAUSE"
        const val ACTION_RESUME = "com.quickdl.app.notif.RESUME"

        fun createPendingIntent(
            context: Context,
            action: String,
            downloadId: String,
            requestCode: Int
        ): PendingIntent {
            val intent = Intent(context, DownloadActionReceiver::class.java).apply {
                this.action = action
                putExtra(DownloadForegroundService.EXTRA_DOWNLOAD_ID, downloadId)
            }
            return PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }
    }
}
