package com.quickdl.app.core.model

data class DownloadProgress(
    val percent: Float = 0f,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = -1L,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long = -1L,
    val phaseLabel: String = "Preparing…"
) {
    val isIndeterminate: Boolean
        get() = percent < 0f || (percent == 0f && downloadedBytes == 0L)
}
