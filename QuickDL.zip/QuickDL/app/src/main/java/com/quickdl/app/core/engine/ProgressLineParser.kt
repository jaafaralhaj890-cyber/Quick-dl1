package com.quickdl.app.core.engine

import com.quickdl.app.core.model.DownloadProgress
import java.util.Locale

/**
 * Parses real yt-dlp stdout progress lines such as:
 *   [download]  42.3% of ~128.45MiB at  6.42MiB/s ETA 00:11
 *   [download]  88.0% of  54.20MiB at  3.10MiB/s ETA 00:02
 *   [Merger] Merging formats into "/path/to/video.mp4"
 */
object ProgressLineParser {

    private val SIZE_REGEX = Regex("of\s+~?(\d+(?:\.\d+)?)\s*([KMGTP]?i?B)", RegexOption.IGNORE_CASE)
    private val SPEED_REGEX = Regex("at\s+(\d+(?:\.\d+)?)\s*([KMGTP]?i?B)/s", RegexOption.IGNORE_CASE)

    fun parse(
        callbackPercent: Float,
        callbackEtaSeconds: Long,
        line: String?,
        previous: DownloadProgress
    ): DownloadProgress {
        val raw = line.orEmpty()

        if (raw.contains("[Merger]", ignoreCase = true) ||
            raw.contains("Merging formats", ignoreCase = true) ||
            raw.contains("[Fixup", ignoreCase = true)
        ) {
            return previous.copy(
                percent = 99f,
                etaSeconds = 0L,
                phaseLabel = "Merging audio & video…"
            )
        }

        if (raw.contains("[ExtractAudio]", ignoreCase = true)) {
            return previous.copy(
                percent = 99f,
                etaSeconds = 0L,
                phaseLabel = "Extracting audio…"
            )
        }

        val totalBytes = SIZE_REGEX.find(raw)?.let { match ->
            toBytes(match.groupValues[1].toDoubleOrNull() ?: 0.0, match.groupValues[2])
        } ?: previous.totalBytes

        val speedBytes = SPEED_REGEX.find(raw)?.let { match ->
            toBytes(match.groupValues[1].toDoubleOrNull() ?: 0.0, match.groupValues[2])
        } ?: previous.speedBytesPerSec

        val percent = if (callbackPercent in 0f..100f) callbackPercent else previous.percent
        val downloadedBytes = if (totalBytes > 0L && percent >= 0f) {
            ((totalBytes.toDouble() * percent.toDouble()) / 100.0).toLong()
        } else {
            previous.downloadedBytes
        }

        val eta = if (callbackEtaSeconds >= 0L) callbackEtaSeconds else previous.etaSeconds

        return DownloadProgress(
            percent = percent,
            downloadedBytes = downloadedBytes,
            totalBytes = totalBytes,
            speedBytesPerSec = speedBytes,
            etaSeconds = eta,
            phaseLabel = if (percent > 0f) "Downloading" else "Starting download…"
        )
    }

    private fun toBytes(value: Double, unit: String): Long {
        val multiplier = when (unit.uppercase(Locale.US)) {
            "B" -> 1.0
            "KB" -> 1_000.0
            "KIB" -> 1_024.0
            "MB" -> 1_000_000.0
            "MIB" -> 1_048_576.0
            "GB" -> 1_000_000_000.0
            "GIB" -> 1_073_741_824.0
            "TB" -> 1_000_000_000_000.0
            "TIB" -> 1_099_511_627_776.0
            else -> 1.0
        }
        return (value * multiplier).toLong()
    }
}
