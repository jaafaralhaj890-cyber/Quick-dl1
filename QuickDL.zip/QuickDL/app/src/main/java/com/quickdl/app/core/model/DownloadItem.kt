package com.quickdl.app.core.model

data class DownloadItem(
    val id: String,
    val url: String,
    val title: String = "Fetching video info…",
    val uploader: String? = null,
    val thumbnailUrl: String? = null,
    val durationSeconds: Long? = null,
    val resolution: String? = null,
    val formatExtension: String? = null,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val progressPercent: Float = 0f,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = -1L,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long = -1L,
    val outputUri: String? = null,
    val outputDisplayPath: String? = null,
    val fileSizeBytes: Long = 0L,
    val errorMessage: String? = null,
    val retryCount: Int = 0,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val completedAtMillis: Long? = null
)
