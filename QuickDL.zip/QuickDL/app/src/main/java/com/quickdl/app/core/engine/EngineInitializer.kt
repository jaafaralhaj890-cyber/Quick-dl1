package com.quickdl.app.core.engine

import android.content.Context
import android.util.Log
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Thread-safe initializer for bundled Python + yt-dlp + FFmpeg + Aria2c native runtimes.
 * Safe to call from Application.onCreate() as well as cold-started TileService / ForegroundService.
 */
object EngineInitializer {
    private const val TAG = "EngineInitializer"
    private val mutex = Mutex()

    @Volatile
    private var initialized = false

    @Volatile
    var ffmpegAvailable = false
        private set

    @Volatile
    var aria2cAvailable = false
        private set

    suspend fun ensureInitialized(context: Context): Result<Unit> {
        if (initialized) return Result.success(Unit)
        return mutex.withLock {
            if (initialized) return Result.success(Unit)
            withContext(Dispatchers.IO) {
                runCatching {
                    val appContext = context.applicationContext
                    YoutubeDL.getInstance().init(appContext)
                    runCatching {
                        FFmpeg.getInstance().init(appContext)
                        ffmpegAvailable = true
                    }.onFailure { e ->
                        Log.w(TAG, "FFmpeg init failed; stream merging may be unavailable", e)
                    }
                    runCatching {
                        Aria2c.getInstance().init(appContext)
                        aria2cAvailable = true
                    }.onFailure { e ->
                        Log.w(TAG, "Aria2c init failed; falling back to native yt-dlp downloader", e)
                    }
                    initialized = true
                }
            }
        }
    }

    suspend fun updateYtDlp(context: Context): Result<YoutubeDL.UpdateStatus?> =
        withContext(Dispatchers.IO) {
            ensureInitialized(context).getOrThrow()
            runCatching {
                YoutubeDL.getInstance().updateYoutubeDL(
                    context.applicationContext,
                    YoutubeDL.UpdateChannel.STABLE
                )
            }
        }
}
