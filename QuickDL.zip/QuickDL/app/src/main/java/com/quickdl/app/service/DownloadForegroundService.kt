package com.quickdl.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.quickdl.app.QuickDlApplication
import com.quickdl.app.core.notification.DownloadNotificationManager
import com.quickdl.app.tile.TileStateBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Long-running Foreground Service (Android 14+ foregroundServiceType="dataSync").
 * Survives main Activity dismissal and process termination recovery via START_STICKY + Room.
 */
class DownloadForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        val app = application as QuickDlApplication
        app.notificationManager.ensureChannels()
        app.queueManager.onActiveCountChanged = { activeCount, aggregatePercent ->
            if (activeCount == 0) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            } else {
                promoteToForeground(activeCount, aggregatePercent)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as QuickDlApplication
        val currentActive = app.queueManager.activeCount().coerceAtLeast(1)
        promoteToForeground(currentActive, 0)

        when (intent?.action) {
            ACTION_ENQUEUE -> {
                val url = intent.getStringExtra(EXTRA_URL)
                if (!url.isNullOrBlank()) {
                    app.queueManager.enqueue(url)
                }
            }

            ACTION_RETRY -> {
                val id = intent.getStringExtra(EXTRA_DOWNLOAD_ID)
                if (!id.isNullOrBlank()) {
                    app.queueManager.retry(id)
                }
            }

            ACTION_RESUME -> {
                val id = intent.getStringExtra(EXTRA_DOWNLOAD_ID)
                if (!id.isNullOrBlank()) {
                    app.queueManager.resume(id)
                }
            }

            ACTION_PAUSE -> {
                val id = intent.getStringExtra(EXTRA_DOWNLOAD_ID)
                if (!id.isNullOrBlank()) {
                    app.queueManager.pause(id)
                }
            }

            ACTION_CANCEL -> {
                val id = intent.getStringExtra(EXTRA_DOWNLOAD_ID)
                if (!id.isNullOrBlank()) {
                    app.queueManager.cancel(id)
                }
            }

            ACTION_RECOVER_PENDING, null -> {
                // Re-enqueue interrupted jobs after process death or network reconnection
                serviceScope.launch {
                    val pending = app.downloadRepository.getPendingOrRunning()
                    if (pending.isEmpty() && app.queueManager.activeCount() == 0) {
                        TileStateBus.setIdle(this@DownloadForegroundService)
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    } else {
                        pending.forEach { item ->
                            app.queueManager.enqueue(item.url, existingId = item.id)
                        }
                    }
                }
            }
        }

        return START_STICKY
    }

    private fun promoteToForeground(activeCount: Int, aggregatePercent: Int) {
        val app = application as QuickDlApplication
        val notification = app.notificationManager.buildForegroundSummaryNotification(
            activeCount = activeCount,
            aggregatePercent = aggregatePercent
        )
        val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else {
            0
        }
        ServiceCompat.startForeground(
            this,
            DownloadNotificationManager.FOREGROUND_SUMMARY_ID,
            notification,
            serviceType
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        val app = application as QuickDlApplication
        app.queueManager.onActiveCountChanged = null
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_ENQUEUE = "com.quickdl.app.action.ENQUEUE"
        const val ACTION_CANCEL = "com.quickdl.app.action.CANCEL"
        const val ACTION_PAUSE = "com.quickdl.app.action.PAUSE"
        const val ACTION_RESUME = "com.quickdl.app.action.RESUME"
        const val ACTION_RETRY = "com.quickdl.app.action.RETRY"
        const val ACTION_RECOVER_PENDING = "com.quickdl.app.action.RECOVER_PENDING"

        const val EXTRA_URL = "extra_url"
        const val EXTRA_DOWNLOAD_ID = "extra_download_id"

        fun enqueueUrl(context: Context, url: String) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                action = ACTION_ENQUEUE
                putExtra(EXTRA_URL, url)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun sendCommand(context: Context, action: String, downloadId: String) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                this.action = action
                putExtra(EXTRA_DOWNLOAD_ID, downloadId)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun recoverPending(context: Context) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                action = ACTION_RECOVER_PENDING
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
