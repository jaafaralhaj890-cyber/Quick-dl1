package com.quickdl.app.core.engine

import android.content.Context
import com.quickdl.app.core.model.AppSettings
import com.quickdl.app.core.model.DownloadProgress
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Production yt-dlp + FFmpeg download engine powered by io.github.junkfood02.youtubedl-android.
 *
 * Key guarantees:
 * - Default mode selects the highest available original video + audio streams without artificial caps.
 * - Uses FFmpeg stream copy/remuxing when merging DASH/HLS video+audio to avoid re-encoding.
 * - Supports resumable downloads (--continue), automatic fragment retries, and process cancellation.
 */
class YtDlpEngine(private val context: Context) : DownloadEngine {

    override suspend fun fetchMetadata(url: String): Result<ExtractedMetadata> =
        withContext(Dispatchers.IO) {
            EngineInitializer.ensureInitialized(context).getOrElse { return@withContext Result.failure(it) }
            runCatching {
                val request = YoutubeDLRequest(url).apply {
                    addOption("--no-playlist")
                    addOption("--socket-timeout", "20")
                }
                val info = YoutubeDL.getInstance().getInfo(request)
                val height = info.height
                val resolution = if (height > 0) "${height}p" else null
                ExtractedMetadata(
                    title = info.title?.takeIf { it.isNotBlank() } ?: "Video",
                    uploader = info.uploader?.takeIf { it.isNotBlank() },
                    thumbnailUrl = info.thumbnail?.takeIf { it.isNotBlank() },
                    durationSeconds = info.duration.takeIf { it > 0 }?.toLong(),
                    resolution = resolution,
                    ext = info.ext?.takeIf { it.isNotBlank() }
                )
            }
        }

    override suspend fun download(
        processId: String,
        url: String,
        stagingDir: File,
        settings: AppSettings,
        onProgress: (DownloadProgress) -> Unit
    ): Result<EngineDownloadResult> = withContext(Dispatchers.IO) {
        EngineInitializer.ensureInitialized(context).getOrElse { return@withContext Result.failure(it) }

        runCatching {
            if (!stagingDir.exists()) stagingDir.mkdirs()

            val outputTemplate = if (settings.autoCleanFilename) {
                File(stagingDir, "%(title).120B.%(ext)s").absolutePath
            } else {
                File(stagingDir, "%(title)s [%(id)s].%(ext)s").absolutePath
            }

            val request = YoutubeDLRequest(url).apply {
                addOption("--no-mtime")
                addOption("--no-playlist")
                addOption("--continue") // Resumable downloads
                addOption("--retries", settings.maxRetryCount.coerceAtLeast(1).toString())
                addOption("--fragment-retries", settings.maxRetryCount.coerceAtLeast(1).toString())
                addOption("--concurrent-fragments", "4")
                addOption("--newline")
                addOption("--socket-timeout", "30")
                addOption("-o", outputTemplate)

                if (settings.autoCleanFilename) {
                    addOption("--restrict-filenames")
                }

                if (settings.audioOnly) {
                    addOption("-f", "bestaudio/best")
                    if (EngineInitializer.ffmpegAvailable) {
                        addOption("-x")
                        addOption("--audio-format", "m4a")
                        addOption("--audio-quality", "0")
                    }
                } else {
                    val formatSelector = buildVideoFormatSelector(settings.qualityPreset.maxHeight)
                    addOption("-f", formatSelector)

                    // Merge separate DASH/HLS video+audio streams via FFmpeg without re-encoding
                    if (EngineInitializer.ffmpegAvailable) {
                        settings.preferredFormat.extension?.let { ext ->
                            addOption("--merge-output-format", ext)
                        }
                    }
                }

                if (settings.useAria2c && EngineInitializer.aria2cAvailable) {
                    addOption("--downloader", "libaria2c.so")
                    addOption("--external-downloader-args", "aria2c:-x 8 -s 8 -k 1M")
                }
            }

            var currentProgress = DownloadProgress(percent = 0f, phaseLabel = "Connecting…")
            onProgress(currentProgress)

            YoutubeDL.getInstance().execute(request, processId) { progress, etaInSeconds, line ->
                currentProgress = ProgressLineParser.parse(
                    callbackPercent = progress,
                    callbackEtaSeconds = etaInSeconds,
                    line = line,
                    previous = currentProgress
                )
                onProgress(currentProgress)
            }

            val finalFile = stagingDir.listFiles()
                ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") && !it.name.endsWith(".temp") }
                ?.maxByOrNull { it.length() }
                ?: throw IllegalStateException("Download finished but no output media file was found.")

            EngineDownloadResult(
                stagedFile = finalFile,
                title = finalFile.nameWithoutExtension,
                extension = finalFile.extension.ifBlank { if (settings.audioOnly) "m4a" else "mp4" },
                resolution = null
            )
        }
    }

    override fun cancel(processId: String): Boolean {
        return runCatching {
            YoutubeDL.getInstance().destroyProcessById(processId)
        }.getOrDefault(false)
    }

    private fun buildVideoFormatSelector(maxHeight: Int?): String {
        return if (maxHeight == null) {
            // Best available original quality (supports 4K/8K, high FPS, HDR, DASH, HLS)
            "bestvideo*+bestaudio/best"
        } else {
            "bestvideo*[height<=$maxHeight]+bestaudio/best[height<=$maxHeight]/best"
        }
    }
}
