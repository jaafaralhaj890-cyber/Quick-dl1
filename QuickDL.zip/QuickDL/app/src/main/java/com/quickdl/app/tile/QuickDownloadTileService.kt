package com.quickdl.app.tile

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.quickdl.app.R
import com.quickdl.app.core.model.TileState

/**
 * Native Android Quick Settings TileService.
 *
 * ONE TAP = START DOWNLOADING:
 * Launches the invisible [ClipboardHandoffActivity] using startActivityAndCollapse() so
 * Android 10–15 grants momentary window focus to read the clipboard without ever opening
 * the main application UI or leaving the user's current app.
 */
class QuickDownloadTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        renderTile(TileStateBus.state.value)
    }

    override fun onTileAdded() {
        super.onTileAdded()
        renderTile(TileStateBus.state.value)
    }

    override fun onClick() {
        super.onClick()
        val launchHandoff = {
            // Immediate lightweight visual feedback in the tile
            qsTile?.let { tile ->
                tile.state = Tile.STATE_ACTIVE
                tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_downloading)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = getString(R.string.tile_subtitle_downloading)
                }
                tile.updateTile()
            }

            val intent = Intent(this, ClipboardHandoffActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_NO_ANIMATION or
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                )
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val pendingIntent = PendingIntent.getActivity(
                    this,
                    REQUEST_CODE_HANDOFF,
                    intent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                startActivityAndCollapse(pendingIntent)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        }

        if (isLocked) {
            unlockAndRun(launchHandoff)
        } else {
            launchHandoff()
        }
    }

    private fun renderTile(state: TileState) {
        val tile = qsTile ?: return
        tile.label = getString(R.string.tile_label)

        when (state) {
            is TileState.Idle -> {
                tile.state = Tile.STATE_INACTIVE
                tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_idle)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = getString(R.string.tile_subtitle_idle)
                }
            }

            is TileState.Downloading -> {
                tile.state = Tile.STATE_ACTIVE
                tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_downloading)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = if (state.activeCount > 1) {
                        "${state.activeCount} active · ${state.aggregatePercent}%"
                    } else if (state.aggregatePercent > 0) {
                        "${state.aggregatePercent}%"
                    } else {
                        getString(R.string.tile_subtitle_downloading)
                    }
                }
            }

            is TileState.Completed -> {
                tile.state = Tile.STATE_ACTIVE
                tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_completed)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = getString(R.string.tile_subtitle_completed)
                }
            }

            is TileState.Error -> {
                tile.state = Tile.STATE_INACTIVE
                tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_error)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = getString(R.string.tile_subtitle_error)
                }
            }
        }

        tile.updateTile()
    }

    companion object {
        private const val REQUEST_CODE_HANDOFF = 4101
    }
}
