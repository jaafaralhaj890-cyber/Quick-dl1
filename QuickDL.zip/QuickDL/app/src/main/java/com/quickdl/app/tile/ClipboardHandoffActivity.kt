package com.quickdl.app.tile

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import com.quickdl.app.QuickDlApplication
import com.quickdl.app.R
import com.quickdl.app.core.clipboard.ClipboardParseResult
import com.quickdl.app.service.DownloadForegroundService
import kotlinx.coroutines.runBlocking
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Invisible, zero-animation Activity whose sole purpose is to satisfy Android 10–15's
 * window-focus requirement for reading [android.content.ClipboardManager].
 *
 * Lifecycle:
 * 1. Launched via TileService.startActivityAndCollapse() in its own isolated taskAffinity.
 * 2. Renders zero views and disables all enter/exit window transitions.
 * 3. As soon as onWindowFocusChanged(true) fires (~30–80ms), reads clipboard URLs,
 *    hands them off to [DownloadForegroundService], and calls finish() immediately.
 * 4. Excluded from Recents and never launches MainActivity.
 */
class ClipboardHandoffActivity : Activity() {

    private val handled = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val safetyTimeoutRunnable = Runnable {
        if (handled.compareAndSet(false, true)) {
            val app = application as QuickDlApplication
            app.notificationManager.showInfoAlert(
                title = getString(R.string.app_name),
                message = getString(R.string.msg_clipboard_blocked)
            )
            TileStateBus.setError(this, getString(R.string.msg_clipboard_blocked))
            finishSilently()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        disableTransitions()
        super.onCreate(savedInstanceState)

        // Ensure zero visual footprint and no dim behind this invisible window
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.setLayout(1, 1)

        // Safety timeout in case OS prevents focus acquisition (e.g., lock screen edge case)
        mainHandler.postDelayed(safetyTimeoutRunnable, 750L)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && handled.compareAndSet(false, true)) {
            mainHandler.removeCallbacks(safetyTimeoutRunnable)
            processClipboardAndFinish()
        }
    }

    private fun processClipboardAndFinish() {
        val app = application as QuickDlApplication
        val settings = runBlocking { app.settingsRepository.getCurrentSettings() }

        if (!settings.quickTileEnabled) {
            app.notificationManager.showInfoAlert(
                title = getString(R.string.app_name),
                message = getString(R.string.msg_tile_disabled)
            )
            TileStateBus.setIdle(this)
            finishSilently()
            return
        }

        when (val result = app.clipboardHandler.readAndExtract()) {
            is ClipboardParseResult.Empty -> {
                app.notificationManager.showInfoAlert(
                    title = getString(R.string.tile_label),
                    message = getString(R.string.msg_empty_clipboard)
                )
                TileStateBus.setIdle(this)
            }

            is ClipboardParseResult.NoValidUrls -> {
                app.notificationManager.showInfoAlert(
                    title = getString(R.string.tile_label),
                    message = getString(R.string.msg_unsupported_url)
                )
                TileStateBus.setError(this, getString(R.string.msg_unsupported_url))
            }

            is ClipboardParseResult.AccessBlocked -> {
                app.notificationManager.showInfoAlert(
                    title = getString(R.string.tile_label),
                    message = getString(R.string.msg_clipboard_blocked)
                )
                TileStateBus.setError(this, getString(R.string.msg_clipboard_blocked))
            }

            is ClipboardParseResult.ValidUrls -> {
                var startedCount = 0
                var duplicateCount = 0

                for (url in result.urls) {
                    val normalized = app.clipboardHandler.normalizeUrl(url)
                    if (app.queueManager.isUrlActive(normalized)) {
                        duplicateCount++
                    } else {
                        DownloadForegroundService.enqueueUrl(this, url)
                        startedCount++
                    }
                }

                if (startedCount == 0 && duplicateCount > 0) {
                    app.notificationManager.showInfoAlert(
                        title = getString(R.string.tile_label),
                        message = getString(R.string.msg_already_downloading)
                    )
                    // Keep active tile state since a download is already running
                }
            }
        }

        finishSilently()
    }

    private fun finishSilently() {
        finish()
        disableTransitions()
    }

    private fun disableTransitions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, 0, 0)
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
        } else {
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(safetyTimeoutRunnable)
        super.onDestroy()
    }
}
