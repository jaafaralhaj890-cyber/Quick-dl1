package com.quickdl.app

import android.app.Application
import com.quickdl.app.core.clipboard.SmartClipboardHandler
import com.quickdl.app.core.engine.DownloadEngine
import com.quickdl.app.core.engine.EngineInitializer
import com.quickdl.app.core.engine.YtDlpEngine
import com.quickdl.app.core.notification.DownloadNotificationManager
import com.quickdl.app.core.queue.DownloadQueueManager
import com.quickdl.app.core.settings.SettingsRepository
import com.quickdl.app.core.storage.StorageManager
import com.quickdl.app.data.db.QuickDlDatabase
import com.quickdl.app.data.repository.DownloadRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class QuickDlApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var database: QuickDlDatabase
        private set
    lateinit var downloadRepository: DownloadRepository
        private set
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var storageManager: StorageManager
        private set
    lateinit var notificationManager: DownloadNotificationManager
        private set
    lateinit var clipboardHandler: SmartClipboardHandler
        private set
    lateinit var downloadEngine: DownloadEngine
        private set
    lateinit var queueManager: DownloadQueueManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = QuickDlDatabase.getInstance(this)
        downloadRepository = DownloadRepository(database.downloadDao())
        settingsRepository = SettingsRepository(this)
        storageManager = StorageManager(this)
        notificationManager = DownloadNotificationManager(this).apply { ensureChannels() }
        clipboardHandler = SmartClipboardHandler(this)
        downloadEngine = YtDlpEngine(this)
        queueManager = DownloadQueueManager(
            context = this,
            engine = downloadEngine,
            repository = downloadRepository,
            storageManager = storageManager,
            notificationManager = notificationManager,
            settingsRepository = settingsRepository,
            clipboardHandler = clipboardHandler
        )

        // Warm up yt-dlp + FFmpeg + Aria2c asynchronously off the main thread for fast cold starts
        appScope.launch {
            EngineInitializer.ensureInitialized(this@QuickDlApplication)
        }
    }
}
