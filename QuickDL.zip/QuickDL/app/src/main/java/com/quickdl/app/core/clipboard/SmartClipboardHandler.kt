package com.quickdl.app.core.clipboard

import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.util.Patterns
import java.util.Locale

sealed class ClipboardParseResult {
    data object Empty : ClipboardParseResult()
    data object AccessBlocked : ClipboardParseResult()
    data object NoValidUrls : ClipboardParseResult()
    data class ValidUrls(val urls: List<String>) : ClipboardParseResult()
}

/**
 * Extracts, validates, normalizes, and deduplicates video URLs strictly on demand
 * after explicit user interaction (Quick Settings Tile tap or Paste button).
 * Never registers an OnPrimaryClipChangedListener or monitors the clipboard in background.
 */
class SmartClipboardHandler(private val context: Context) {

    fun readAndExtract(): ClipboardParseResult {
        val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            ?: return ClipboardParseResult.AccessBlocked

        val clip = try {
            if (!manager.hasPrimaryClip()) {
                return ClipboardParseResult.Empty
            }
            manager.primaryClip
        } catch (_: SecurityException) {
            return ClipboardParseResult.AccessBlocked
        }

        if (clip == null || clip.itemCount == 0) {
            // On Android 10+, primaryClip returns null when window focus is absent.
            return ClipboardParseResult.AccessBlocked
        }

        val collectedText = buildString {
            for (i in 0 until clip.itemCount) {
                val item = clip.getItemAt(i)
                val text = item.coerceToText(context)?.toString().orEmpty()
                if (text.isNotBlank()) {
                    append(text)
                    append('\n')
                }
            }
        }.trim()

        if (collectedText.isBlank()) {
            return ClipboardParseResult.Empty
        }

        return extractUrlsFromText(collectedText)
    }

    fun extractUrlsFromText(rawText: String): ClipboardParseResult {
        if (rawText.isBlank()) return ClipboardParseResult.Empty

        val matcher = Patterns.WEB_URL.matcher(rawText)
        val seenNormalized = LinkedHashSet<String>()
        val validUrls = mutableListOf<String>()

        while (matcher.find()) {
            val rawCandidate = matcher.group().trimEnd('.', ',', ';', ')', ']', '"', '\'')
            val withScheme = if (rawCandidate.startsWith("http://", ignoreCase = true) ||
                rawCandidate.startsWith("https://", ignoreCase = true)
            ) {
                rawCandidate
            } else {
                "https://$rawCandidate"
            }

            if (isSupportedHttpUrl(withScheme)) {
                val normalized = normalizeUrl(withScheme)
                if (seenNormalized.add(normalized)) {
                    validUrls.add(withScheme)
                }
            }
        }

        return if (validUrls.isEmpty()) {
            ClipboardParseResult.NoValidUrls
        } else {
            ClipboardParseResult.ValidUrls(validUrls)
        }
    }

    private fun isSupportedHttpUrl(candidate: String): Boolean {
        val uri = runCatching { Uri.parse(candidate) }.getOrNull() ?: return false
        val scheme = uri.scheme?.lowercase(Locale.US) ?: return false
        if (scheme != "http" && scheme != "https") return false
        val host = uri.host?.lowercase(Locale.US) ?: return false
        if (host.isBlank() || !host.contains('.')) return false
        if (host == "localhost" || host.endsWith(".local")) return false
        return true
    }

    fun normalizeUrl(url: String): String {
        val uri = runCatching { Uri.parse(url.trim()) }.getOrNull() ?: return url.trim()
        val host = uri.host?.lowercase(Locale.US)?.removePrefix("www.")?.removePrefix("m.") ?: ""
        val path = uri.path.orEmpty().trimEnd('/')
        // Strip common tracking query params while preserving video identifiers (e.g. ?v=...)
        val keptParams = uri.queryParameterNames
            .filterNot { key ->
                val lower = key.lowercase(Locale.US)
                lower.startsWith("utm_") || lower in TRACKING_PARAMS
            }
            .sorted()
            .joinToString("&") { key -> "$key=${uri.getQueryParameter(key).orEmpty()}" }

        return if (keptParams.isEmpty()) "$host$path" else "$host$path?$keptParams"
    }

    companion object {
        private val TRACKING_PARAMS = setOf(
            "si", "feature", "pp", "fbclid", "igshid", "igsh", "s", "t", "ref", "ref_src"
        )
    }
}
