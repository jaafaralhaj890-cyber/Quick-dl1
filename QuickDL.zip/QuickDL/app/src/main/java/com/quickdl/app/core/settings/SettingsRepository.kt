package com.quickdl.app.core.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.quickdl.app.core.model.AppSettings
import com.quickdl.app.core.model.PreferredFormat
import com.quickdl.app.core.model.ThemeMode
import com.quickdl.app.core.model.VideoQualityPreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "quickdl_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val QUALITY = stringPreferencesKey("quality_preset")
        val AUDIO_ONLY = booleanPreferencesKey("audio_only")
        val PREFERRED_FORMAT = stringPreferencesKey("preferred_format")
        val CUSTOM_TREE_URI = stringPreferencesKey("custom_tree_uri")
        val MAX_CONCURRENT = intPreferencesKey("max_concurrent")
        val MAX_RETRIES = intPreferencesKey("max_retries")
        val USE_ARIA2C = booleanPreferencesKey("use_aria2c")
        val SHOW_NOTIFICATIONS = booleanPreferencesKey("show_notifications")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLORS = booleanPreferencesKey("dynamic_colors")
        val QUICK_TILE_ENABLED = booleanPreferencesKey("quick_tile_enabled")
        val AUTO_CLEAN_FILENAME = booleanPreferencesKey("auto_clean_filename")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            qualityPreset = prefs[Keys.QUALITY]?.let {
                runCatching { VideoQualityPreset.valueOf(it) }.getOrNull()
            } ?: VideoQualityPreset.BEST,
            audioOnly = prefs[Keys.AUDIO_ONLY] ?: false,
            preferredFormat = prefs[Keys.PREFERRED_FORMAT]?.let {
                runCatching { PreferredFormat.valueOf(it) }.getOrNull()
            } ?: PreferredFormat.AUTO,
            customTreeUri = prefs[Keys.CUSTOM_TREE_URI],
            maxConcurrentDownloads = (prefs[Keys.MAX_CONCURRENT] ?: 2).coerceIn(1, 5),
            maxRetryCount = (prefs[Keys.MAX_RETRIES] ?: 3).coerceIn(0, 10),
            useAria2c = prefs[Keys.USE_ARIA2C] ?: false,
            showNotifications = prefs[Keys.SHOW_NOTIFICATIONS] ?: true,
            themeMode = prefs[Keys.THEME_MODE]?.let {
                runCatching { ThemeMode.valueOf(it) }.getOrNull()
            } ?: ThemeMode.SYSTEM,
            dynamicColors = prefs[Keys.DYNAMIC_COLORS] ?: true,
            quickTileEnabled = prefs[Keys.QUICK_TILE_ENABLED] ?: true,
            autoCleanFilename = prefs[Keys.AUTO_CLEAN_FILENAME] ?: true
        )
    }

    suspend fun getCurrentSettings(): AppSettings = settingsFlow.first()

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        val updated = transform(getCurrentSettings())
        context.dataStore.edit { prefs ->
            prefs[Keys.QUALITY] = updated.qualityPreset.name
            prefs[Keys.AUDIO_ONLY] = updated.audioOnly
            prefs[Keys.PREFERRED_FORMAT] = updated.preferredFormat.name
            if (updated.customTreeUri != null) {
                prefs[Keys.CUSTOM_TREE_URI] = updated.customTreeUri
            } else {
                prefs.remove(Keys.CUSTOM_TREE_URI)
            }
            prefs[Keys.MAX_CONCURRENT] = updated.maxConcurrentDownloads.coerceIn(1, 5)
            prefs[Keys.MAX_RETRIES] = updated.maxRetryCount.coerceIn(0, 10)
            prefs[Keys.USE_ARIA2C] = updated.useAria2c
            prefs[Keys.SHOW_NOTIFICATIONS] = updated.showNotifications
            prefs[Keys.THEME_MODE] = updated.themeMode.name
            prefs[Keys.DYNAMIC_COLORS] = updated.dynamicColors
            prefs[Keys.QUICK_TILE_ENABLED] = updated.quickTileEnabled
            prefs[Keys.AUTO_CLEAN_FILENAME] = updated.autoCleanFilename
        }
    }
}
