package com.quickdl.app.core.storage

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.IOException

data class PublishedMedia(
    val uri: Uri,
    val displayPath: String,
    val fileSizeBytes: Long,
    val mimeType: String
)

/**
 * Manages app-private staging directories for yt-dlp / FFmpeg merging and publishes
 * finished media atomically to Movies/Downloader/ (or a user-selected SAF folder) so
 * completed videos appear immediately in the Android Gallery without unnecessary permissions.
 */
class StorageManager(private val context: Context) {

    fun createStagingDir(downloadId: String): File {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        return File(base, "staging/$downloadId").apply { mkdirs() }
    }

    fun cleanupStagingDir(downloadId: String) {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        File(base, "staging/$downloadId").deleteRecursively()
    }

    suspend fun publishFile(
        stagedFile: File,
        desiredTitle: String,
        extension: String,
        isAudioOnly: Boolean,
        customTreeUri: String?
    ): Result<PublishedMedia> = withContext(Dispatchers.IO) {
        runCatching {
            val safeBaseName = sanitizeFilename(desiredTitle).ifBlank { "video_${System.currentTimeMillis()}" }
            val ext = extension.lowercase().trimStart('.')
            val mimeType = resolveMimeType(ext, isAudioOnly)

            if (!customTreeUri.isNullOrBlank()) {
                return@runCatching publishToSafTree(stagedFile, safeBaseName, ext, mimeType, Uri.parse(customTreeUri))
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                publishViaMediaStore(stagedFile, safeBaseName, ext, mimeType, isAudioOnly)
            } else {
                publishToLegacyPublicDir(stagedFile, safeBaseName, ext, mimeType, isAudioOnly)
            }
        }
    }

    private fun publishViaMediaStore(
        stagedFile: File,
        safeBaseName: String,
        ext: String,
        mimeType: String,
        isAudioOnly: Boolean
    ): PublishedMedia {
        val resolver = context.contentResolver
        val relativePath = if (isAudioOnly) {
            "${Environment.DIRECTORY_MUSIC}/Downloader"
        } else {
            "${Environment.DIRECTORY_MOVIES}/Downloader"
        }

        val collection = if (isAudioOnly) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }

        val fileName = "$safeBaseName.$ext"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val itemUri = resolver.insert(collection, values)
            ?: throw IOException("Failed to create MediaStore entry in $relativePath")

        try {
            resolver.openOutputStream(itemUri)?.use { out ->
                FileInputStream(stagedFile).use { input ->
                    input.copyTo(out, bufferSize = 64 * 1024)
                }
            } ?: throw IOException("Failed to open output stream for $itemUri")

            val publishValues = ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }
            resolver.update(itemUri, publishValues, null, null)

            return PublishedMedia(
                uri = itemUri,
                displayPath = "$relativePath/$fileName",
                fileSizeBytes = stagedFile.length(),
                mimeType = mimeType
            )
        } catch (t: Throwable) {
            resolver.delete(itemUri, null, null)
            throw t
        }
    }

    private fun publishToSafTree(
        stagedFile: File,
        safeBaseName: String,
        ext: String,
        mimeType: String,
        treeUri: Uri
    ): PublishedMedia {
        val tree = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IOException("Selected custom folder is no longer accessible.")

        var candidateName = "$safeBaseName.$ext"
        var index = 1
        while (tree.findFile(candidateName) != null) {
            candidateName = "$safeBaseName ($index).$ext"
            index++
        }

        val target = tree.createFile(mimeType, candidateName.removeSuffix(".$ext"))
            ?: throw IOException("Could not create file in selected folder.")

        context.contentResolver.openOutputStream(target.uri)?.use { out ->
            FileInputStream(stagedFile).use { input ->
                input.copyTo(out, bufferSize = 64 * 1024)
            }
        } ?: throw IOException("Failed to write to selected custom folder.")

        return PublishedMedia(
            uri = target.uri,
            displayPath = "${tree.name ?: "Custom Folder"}/$candidateName",
            fileSizeBytes = stagedFile.length(),
            mimeType = mimeType
        )
    }

    @Suppress("DEPRECATION")
    private fun publishToLegacyPublicDir(
        stagedFile: File,
        safeBaseName: String,
        ext: String,
        mimeType: String,
        isAudioOnly: Boolean
    ): PublishedMedia {
        val rootDir = Environment.getExternalStoragePublicDirectory(
            if (isAudioOnly) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        )
        val targetDir = File(rootDir, "Downloader").apply { mkdirs() }
        var dest = File(targetDir, "$safeBaseName.$ext")
        var counter = 1
        while (dest.exists()) {
            dest = File(targetDir, "$safeBaseName ($counter).$ext")
            counter++
        }

        stagedFile.copyTo(dest, overwrite = false)
        MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), arrayOf(mimeType), null)

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", dest)
        return PublishedMedia(
            uri = uri,
            displayPath = "Movies/Downloader/${dest.name}",
            fileSizeBytes = dest.length(),
            mimeType = mimeType
        )
    }

    private fun sanitizeFilename(name: String): String {
        return name
            .replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(110)
    }

    private fun resolveMimeType(ext: String, isAudioOnly: Boolean): String {
        val mapped = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        if (!mapped.isNullOrBlank()) return mapped
        return if (isAudioOnly) "audio/mp4" else "video/mp4"
    }
}
