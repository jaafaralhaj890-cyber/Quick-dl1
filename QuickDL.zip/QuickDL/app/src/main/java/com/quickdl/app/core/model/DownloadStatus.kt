package com.quickdl.app.core.model

enum class DownloadStatus {
    QUEUED,
    EXTRACTING,
    DOWNLOADING,
    MERGING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED;

    val isActive: Boolean
        get() = this == QUEUED || this == EXTRACTING || this == DOWNLOADING || this == MERGING
}
