package com.quickdl.app.core.model

enum class VideoQualityPreset(val label: String, val maxHeight: Int?) {
    BEST("Best available (4K/8K)", null),
    UHD_2160("Up to 2160p (4K)", 2160),
    QHD_1440("Up to 1440p", 1440),
    FHD_1080("Up to 1080p", 1080),
    HD_720("Up to 720p", 720)
}

enum class PreferredFormat(val label: String, val extension: String?) {
    AUTO("Original (no re-encode)", null),
    MP4("MP4 (remux)", "mp4"),
    MKV("MKV (remux)", "mkv"),
    WEBM("WebM", "webm")
}

enum class ThemeMode(val label: String) {
    SYSTEM("System default"),
    DARK("Dark"),
    LIGHT("Light")
}

data class AppSettings(
    val qualityPreset: VideoQualityPreset = VideoQualityPreset.BEST,
    val audioOnly: Boolean = false,
    val preferredFormat: PreferredFormat = PreferredFormat.AUTO,
    val customTreeUri: String? = null,
    val maxConcurrentDownloads: Int = 2,
    val maxRetryCount: Int = 3,
    val useAria2c: Boolean = false,
    val showNotifications: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColors: Boolean = true,
    val quickTileEnabled: Boolean = true,
    val autoCleanFilename: Boolean = true
)
