package com.quickdl.app.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.quickdl.app.core.model.DownloadItem
import com.quickdl.app.core.model.DownloadStatus

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val url: String,
    val normalizedUrl: String,
    val title: String,
    val uploader: String?,
    val thumbnailUrl: String?,
    val durationSeconds: Long?,
    val resolution: String?,
    val formatExtension: String?,
    val status: String,
    val progressPercent: Float,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val speedBytesPerSec: Long,
    val etaSeconds: Long,
    val outputUri: String?,
    val outputDisplayPath: String?,
    val fileSizeBytes: Long,
    val errorMessage: String?,
    val retryCount: Int,
    val createdAtMillis: Long,
    val completedAtMillis: Long?
) {
    fun toModel(): DownloadItem = DownloadItem(
        id = id,
        url = url,
        title = title,
        uploader = uploader,
        thumbnailUrl = thumbnailUrl,
        durationSeconds = durationSeconds,
        resolution = resolution,
        formatExtension = formatExtension,
        status = runCatching { DownloadStatus.valueOf(status) }.getOrDefault(DownloadStatus.FAILED),
        progressPercent = progressPercent,
        downloadedBytes = downloadedBytes,
        totalBytes = totalBytes,
        speedBytesPerSec = speedBytesPerSec,
        etaSeconds = etaSeconds,
        outputUri = outputUri,
        outputDisplayPath = outputDisplayPath,
        fileSizeBytes = fileSizeBytes,
        errorMessage = errorMessage,
        retryCount = retryCount,
        createdAtMillis = createdAtMillis,
        completedAtMillis = completedAtMillis
    )

    companion object {
        fun fromModel(item: DownloadItem, normalizedUrl: String): DownloadEntity = DownloadEntity(
            id = item.id,
            url = item.url,
            normalizedUrl = normalizedUrl,
            title = item.title,
            uploader = item.uploader,
            thumbnailUrl = item.thumbnailUrl,
            durationSeconds = item.durationSeconds,
            resolution = item.resolution,
            formatExtension = item.formatExtension,
            status = item.status.name,
            progressPercent = item.progressPercent,
            downloadedBytes = item.downloadedBytes,
            totalBytes = item.totalBytes,
            speedBytesPerSec = item.speedBytesPerSec,
            etaSeconds = item.etaSeconds,
            outputUri = item.outputUri,
            outputDisplayPath = item.outputDisplayPath,
            fileSizeBytes = item.fileSizeBytes,
            errorMessage = item.errorMessage,
            retryCount = item.retryCount,
            createdAtMillis = item.createdAtMillis,
            completedAtMillis = item.completedAtMillis
        )
    }
}
