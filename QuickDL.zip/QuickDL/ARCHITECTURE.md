# QuickDL — Technical Architecture & YTDLnis Integration Guide

## 1. Modular Component Separation

QuickDL cleanly separates all 12 responsibilities into focused packages under `com.quickdl.app`:

| Layer | Package / Class | Responsibility |
| --- | --- | --- |
| **Quick Settings Tile** | `tile/QuickDownloadTileService.kt`, `tile/TileStateBus.kt` | Native `TileService` with 4 states (`Idle`, `Downloading`, `Completed`, `Error`) and live subtitle updates |
| **Invisible Clipboard Handoff** | `tile/ClipboardHandoffActivity.kt` | Transparent, zero-animation Activity (`taskAffinity=""`, `excludeFromRecents="true"`, `noHistory="true"`) that acquires momentary focus on Android 10–15 to read clipboard and immediately exits |
| **Clipboard Handler** | `core/clipboard/SmartClipboardHandler.kt` | On-demand URL extraction, multi-URL parsing, HTTP/HTTPS validation, tracking-param normalization, and duplicate detection (never monitors clipboard in background) |
| **Download Engine Abstraction** | `core/engine/DownloadEngine.kt` | Engine-agnostic interface (`fetchMetadata`, `download`, `cancel`) |
| **yt-dlp + FFmpeg + Aria2c** | `core/engine/YtDlpEngine.kt`, `EngineInitializer.kt`, `ProgressLineParser.kt` | Real `io.github.junkfood02.youtubedl-android` execution, FFmpeg stream merging, and stdout progress parsing |
| **Download Queue** | `core/queue/DownloadQueueManager.kt` | Semaphore-bounded concurrent downloads, dedup, exponential retry backoff, pause/resume/cancel/retry |
| **Foreground Service** | `service/DownloadForegroundService.kt`, `DownloadActionReceiver.kt`, `DownloadRecoveryWorker.kt` | Android 14+ `dataSync` Foreground Service, notification action broadcast receiver, and WorkManager network-restored recovery |
| **Notification Manager** | `core/notification/DownloadNotificationManager.kt` | Thumbnail prefetch, 400ms throttled progress notifications, grouped summary, Open/Share/Retry/Cancel actions |
| **Storage Manager** | `core/storage/StorageManager.kt` | App-private staging for FFmpeg merges + atomic `MediaStore` publish (`Movies/Downloader/`) + SAF custom folder support |
| **Persistent History** | `data/db/QuickDlDatabase.kt`, `DownloadDao.kt`, `DownloadRepository.kt` | Room persistence for active queue recovery and download history |
| **Settings Manager** | `core/settings/SettingsRepository.kt` | Jetpack DataStore preferences (quality, format, audio-only, concurrency, retries, Aria2c, theme, tile toggle) |
| **UI Layer** | `ui/MainActivity.kt`, `MainViewModel.kt`, `screens/*` | Material 3 + Dynamic Color Jetpack Compose interface (never opened by the Quick Settings tile) |

## 2. How the Invisible Android 10–15 Clipboard Handoff Works

On Android 10 (API 29) and higher, `ClipboardManager.getPrimaryClip()` returns `null` if called from a background `Service` (including `TileService.onClick()`). QuickDL solves this cleanly without breaking the "never open the main app" UX:

1. User taps the **Quick Download** tile in the notification shade.
2. `QuickDownloadTileService.onClick()` immediately updates the tile icon to the downloading state and calls `startActivityAndCollapse(PendingIntent)` (API 34+) or `startActivityAndCollapse(Intent)` (API 26–33) targeting `ClipboardHandoffActivity`.
3. `ClipboardHandoffActivity` is declared with:
   - `android:theme="@style/Theme.QuickDL.TransparentHandoff"` (`windowIsTranslucent=true`, `backgroundDimEnabled=false`, `windowAnimationStyle=@null`, `windowDisablePreview=true`)
   - `android:taskAffinity=""` (isolated from `MainActivity`'s task stack so `MainActivity` is never brought forward)
   - `android:excludeFromRecents="true"` and `android:noHistory="true"`
   - `overrideActivityTransition(..., 0, 0)` (API 34+) / `overridePendingTransition(0, 0)`
4. Within ~30–80ms, `onWindowFocusChanged(hasFocus = true)` fires. `ClipboardHandoffActivity` calls `SmartClipboardHandler.readAndExtract()`, hands valid non-duplicate URLs directly to `DownloadForegroundService.enqueueUrl(...)`, and calls `finish()` immediately.
5. A 750ms safety timeout guarantees the Activity always terminates and posts a helpful alert notification if the OS denies focus.

## 3. Integrating `deniscerri/ytdlnis` Components Later

Because QuickDL isolates the extraction/download backend behind `com.quickdl.app.core.engine.DownloadEngine`, you can port mature modules from [`deniscerri/ytdlnis`](https://github.com/deniscerri/ytdlnis) without modifying the Quick Settings tile, notification system, or Compose UI:

- **Command Templates & Custom yt-dlp Flags**: Extend `YtDlpEngine.download()` to append YTDLnis `CommandTemplate` arguments to `YoutubeDLRequest`.
- **Cookies & PO-Token Providers**: Pass `--cookies <path>` (exported via YTDLnis's WebView cookie manager) or BGUtils PO-token extractor arguments inside `YtDlpEngine` for authenticated/age-restricted or YouTube challenge-protected streams.
- **SponsorBlock / Chapter Cutting / Subtitle Embedding**: Add `--sponsorblock-remove`, `--embed-subs`, or `--embed-thumbnail` options to `AppSettings` and map them in `YtDlpEngine`.
- **NewPipe / Hybrid Metadata Extractor**: Swap `YtDlpEngine.fetchMetadata()` to use a fast extractor while keeping `YoutubeDL.getInstance().execute()` for downloading and FFmpeg merging.
