# Build QuickDL from an Android phone (no PC required)

This project includes a GitHub Actions workflow that builds the APK in the cloud.

1. Sign in to GitHub in your phone browser.
2. Create a repository named `QuickDL`.
3. Upload the **contents** of this `QuickDL` folder to the repository root. Make sure the hidden `.github` folder and its workflow file are included.
4. Open the repository's **Actions** tab and select **Build QuickDL APK**.
5. Tap **Run workflow**. If the button is unavailable, commit/push the files to the `main` or `master` branch to trigger the workflow.
6. Wait for the run to finish. A green check means the Gradle build and unit tests passed.
7. Open the completed run, find **Artifacts**, and download `QuickDL-debug-apks`.
8. Extract the artifact ZIP and install the APK for your phone architecture. Most modern Android phones use `arm64-v8a`; choose the universal APK if one is included.

## Important

- This workflow performs a real cloud Gradle build and unit tests. It cannot test Quick Settings clipboard behavior or real downloads on your physical phone.
- Internet access is required on the GitHub runner to download Gradle and Maven dependencies.
- The output is a debug APK, not a Play Store-signed release.
- The source archive did not contain `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`; this workflow installs Gradle 8.11.1 directly, so no local Gradle installation is needed.
